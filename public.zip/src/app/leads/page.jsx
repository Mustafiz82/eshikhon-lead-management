import react from "react"

const page = () => {
    return <div>
        leads 
    </div>
}


export default page