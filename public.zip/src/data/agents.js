export const agents = [
    { name: "Agent A", pendingLeads: 5, assignedLeads: 12 },
    { name: "Agent B", pendingLeads: 2, assignedLeads: 20 },
    { name: "Agent B", pendingLeads: 2, assignedLeads: 20 },
    { name: "Agent B", pendingLeads: 2, assignedLeads: 20 },
    { name: "Agent C", pendingLeads: 8, assignedLeads: 7 },
];
